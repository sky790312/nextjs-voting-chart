# nextjs-voting-chart

a small sample project which contain all real project need.(storybook, unit test..etc.)

## How to use

check the package.json

```
  yarn
  yarn dev
```

## pending

- Use suitable chart library for ui feature.
- Use real data to show.
- Handle user answer.
- UI completed.